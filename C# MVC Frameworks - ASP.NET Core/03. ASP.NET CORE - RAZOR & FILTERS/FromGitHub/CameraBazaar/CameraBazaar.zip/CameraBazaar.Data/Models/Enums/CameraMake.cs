﻿namespace CameraBazaar.Data.Models.Enums
{
    public enum CameraMake
    {
        Canon = 0,
        Nikon = 1,
        Penta = 2,
        Sony = 3
    }
}