﻿namespace CameraBazaar.Data.Models.Enums
{
    public enum CameraMinIso
    {
        Iso50 = 50,
        Iso100 = 100
    }
}