﻿namespace CameraBazaar.Services.Contracts
{
    public interface IService
    {
    }
}