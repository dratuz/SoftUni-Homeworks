﻿using System;

public class WareHouse : IWareHouse
{
    public void EquipArmy(IArmy army)
    {
        throw new NotImplementedException();
    }
}
