﻿public class Hard : Mission
{
    public Hard(double endurance, double score) : base(endurance, score)
    {
    }
}
