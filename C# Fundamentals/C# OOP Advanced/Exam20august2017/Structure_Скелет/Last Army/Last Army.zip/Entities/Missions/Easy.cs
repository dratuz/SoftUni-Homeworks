﻿class Easy : Mission
{
    public Easy(double endurance, double score) : base(endurance, score)
    {
    }
}
