﻿class Medium : Mission
{
    public Medium(double endurance, double score) : base(endurance, score)
    {
    }
}
