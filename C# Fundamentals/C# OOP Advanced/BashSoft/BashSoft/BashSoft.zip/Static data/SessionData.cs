﻿namespace BashSoft
{
    using System.IO;

    public static class SessionData
    {
        public static string currentPath = Directory.GetCurrentDirectory();
    }
}
