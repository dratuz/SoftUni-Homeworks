﻿namespace BashSoft.Contracts
{
    public interface IDirectoryCreator
    {
        void CreateDirectoryInCurrentFolder(string name);
    }
}
