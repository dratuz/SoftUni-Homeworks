﻿namespace BashSoft.Contracts
{
    public interface IExecutable
    {
        void Execute();
    }
}
