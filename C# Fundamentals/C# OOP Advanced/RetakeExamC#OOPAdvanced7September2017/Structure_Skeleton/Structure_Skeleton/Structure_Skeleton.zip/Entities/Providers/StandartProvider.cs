﻿public class StandartProvider : Provider
{
    public StandartProvider(string id, double energyOutput, double durability) 
        : base(id, energyOutput, durability)
    {
    }
}
