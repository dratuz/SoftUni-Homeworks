﻿public class StandartHarvester : Harvester
{
    public StandartHarvester(string id, double oreOutput, double energyRequirement) 
        : base(id, oreOutput,
        energyRequirement)
    {
    }
}