﻿public class BaseEntity
{
    public static void Main(string[] args)
    {
        Engine engine = new Engine();
        engine.Run();
    }
}